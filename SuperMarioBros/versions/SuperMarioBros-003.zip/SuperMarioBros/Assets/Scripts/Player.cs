﻿using UnityEngine;

public class Player : MonoBehaviour
{
    float speed = 8f;
    float jumpSpeed = 255;
    float playerHeight;
    Vector2 startPostion;
    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        startPostion = transform.position;
        playerHeight = GetComponent<Collider2D>().bounds.size.y;
        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        transform.Translate(horizontal * speed * Time.deltaTime, 0, 0);

        float jump = Input.GetAxisRaw("Jump");
        if (jump > 0)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position,
                new Vector2(0, -1));

            if (hit.collider != null)
            {
                float floorDistance = hit.distance;
                bool grounded = floorDistance < playerHeight * 0.6f;
                if (grounded)
                {
                    Vector3 jumpForce = new Vector3(0, jumpSpeed, 0);
                    GetComponent<Rigidbody2D>().AddForce(jumpForce);
                }
            }
        }

        if (horizontal > 0.1f)
        {
            transform.localScale =
                new Vector3(1, transform.localScale.y, transform.localScale.z);
            anim.Play("Walking");
        }
        else if (horizontal < -0.1f)
        {
            transform.localScale = 
                new Vector3(-1, transform.localScale.y, transform.localScale.z);
            anim.Play("Walking");
        }
    }

    public void Reset()
    {
        transform.position = startPostion;
    }
}
