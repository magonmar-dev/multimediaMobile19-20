﻿using UnityEngine;

public class Enemy : MonoBehaviour
{
    private float enemySpeed = -2.5f;
    Rigidbody2D rb;
    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        rb = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity = new Vector2(enemySpeed, rb.velocity.y);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Pipe")
            enemySpeed = -enemySpeed;
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag == "Player")
        {
            anim.Play("EnemyDeath");
            enemySpeed = 0;
            Invoke("DestroEnemy", .5f);
            gameObject.GetComponent<CircleCollider2D>().enabled = false;
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
            gameObject.GetComponent<Rigidbody2D>().gravityScale = 0;
            other.gameObject.GetComponent<Rigidbody2D>().AddForce(Vector2.up * 400);
        }
    }

    public void DestroEnemy()
    {
        Destroy(gameObject);
        CancelInvoke();
    }
}
