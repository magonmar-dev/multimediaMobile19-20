﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    float speed = 2.5f;
    float jumpSpeed = 20;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        transform.Translate(horizontal * speed * Time.deltaTime, 0, 0);

        float jump = Input.GetAxis("Jump");
        if (jump > 0)
        {
            Vector3 force = new Vector3(0, jumpSpeed, 0);
            GetComponent<Rigidbody2D>().AddForce(force);
        }
    }
}
