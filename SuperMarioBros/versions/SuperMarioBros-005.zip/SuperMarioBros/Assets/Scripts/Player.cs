﻿using UnityEngine;

public class Player : MonoBehaviour
{
    float speed = 8f;
    float jumpSpeed = 280;
    float playerHeight;
    Vector2 startPostion;
    Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        startPostion = transform.position;
        playerHeight = GetComponent<Collider2D>().bounds.size.y;
        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        transform.Translate(horizontal * speed * Time.deltaTime, 0, 0);

        float jump = Input.GetAxisRaw("Jump");
        if (jump > 0)
        {
            anim.Play("Jumping");
            RaycastHit2D hit = Physics2D.Raycast(transform.position,
                new Vector2(0, -1));

            if (hit.collider != null)
            {
                float floorDistance = hit.distance;
                bool grounded = floorDistance < playerHeight * 0.6f;
                if (grounded)
                {
                    Vector3 jumpForce = new Vector3(0, jumpSpeed, 0);
                    GetComponent<Rigidbody2D>().AddForce(jumpForce);
                }
            }
        }

        if (horizontal > 0.1f && jump <= 0)
        {
            transform.localScale =
                new Vector3(1, transform.localScale.y, transform.localScale.z);
            anim.Play("Walking");
        }
        else if (horizontal < -0.1f && jump <= 0)
        {
            transform.localScale = 
                new Vector3(-1, transform.localScale.y, transform.localScale.z);
            anim.Play("Walking");
        }
    }

    public void Reset()
    {
        transform.position = startPostion;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "LowerLimit")
            Reset();

        if(other.tag == "Pole")
            Debug.Log("Level finished");

        if (other.tag == "Enemy")
            Debug.Log("Lose life");
    }
}
